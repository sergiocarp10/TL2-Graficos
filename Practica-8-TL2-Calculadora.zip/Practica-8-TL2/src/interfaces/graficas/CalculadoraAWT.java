package interfaces.graficas;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

public class CalculadoraAWT extends JFrame {

    private final JTextField tfPantalla;
    //Botones número
    private final JButton[] btnNumeros;

    //Botones
    private final JToggleButton btnM;
    private final JButton btnRetroceso;
    private final JButton btnCE;
    private final JButton btnC;
    private final JButton btnMC;
    private final JButton btnMR;
    private final JButton btnMS;
    private final JButton btnMPlus;

    //Botones operaciones
    private final JButton btnMasSobreMenos;
    private final JButton btnComa;
    private final JButton btnDivision;
    private final JButton btnMultiplicar;
    private final JButton btnMenos;
    private final JButton btnMas;
    private final JButton btnSqrt;
    private final JButton btnPorcentaje;
    private final JButton btnUnoSobreX;
    private final JButton btnIgual;
    private final static StyledButtonUI StyledButtonUI = new StyledButtonUI();
    private final static StyledButtonUI2 StyledButtonUI2 = new StyledButtonUI2();
    private final static StyledButtonUI3 StyledButtonUI3 = new StyledButtonUI3();

    public CalculadoraAWT() {
        setLayout(new GridBagLayout()); // this.setLayout(...)
        setTitle("Calculadora");
        setSize(400,330);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(179, 179, 177));
       // setResizable(false);

        Font font = new Font("Arial",Font.BOLD, 20);

        //Constraints para el GridBagLayout Inicio
        GridBagConstraints gbc = new GridBagConstraints();

        //Define la posición en x del componente.
        gbc.gridx = 0;
        //Define la posición en y del componente.
        gbc.gridy = 0;

        //Define el número de filas que tóma.
        gbc.gridheight = 1;
        //Define el número de columnas que tóma.
        gbc.gridwidth = 1;

        //Define el padding.
        gbc.insets = new Insets(5,5,5,5);

        //Para asegurarse de que las componentes llenen el tamaño de la ventana
        //establezco los pesos en 1.
        //El peso se utiliza para determinar cómo distribuir el espacio entre filas y columnas.
        gbc.weightx = 1;
        gbc.weighty = 1;

        //Que ocupen el espacio horizontal que puedan.
        //El fill puede ser horizontal o vertical o ambos o ninguno.
        gbc.fill = GridBagConstraints.BOTH;

        //Indica como posicionar un componente en la celda.
        gbc.anchor = GridBagConstraints.CENTER;

        //Constraints para el GridBagLayout Fin

        //Botones numeros Inicio
        btnNumeros = new JButton[10];
        for (int i = 0; i < 10; i++) {
            btnNumeros[i] = new JButton(Integer.toString(i));
            btnNumeros[i].setFont(font);
            btnNumeros[i].setForeground(Color.WHITE);
            btnNumeros[i].setUI(StyledButtonUI);
        }
        btnMasSobreMenos = new JButton("+/-");
        btnMasSobreMenos.setFont(font);
        btnMasSobreMenos.setForeground(Color.WHITE);
        btnMasSobreMenos.setUI(StyledButtonUI);

        btnComa = new JButton(",");
        btnComa.setFont(font);
        btnComa.setForeground(Color.WHITE);
        btnComa.setUI(StyledButtonUI);

        btnSqrt = new JButton("sqrt");
        btnSqrt.setFont(font);
        btnSqrt.setForeground(Color.WHITE);
        btnSqrt.setUI(StyledButtonUI);

        btnPorcentaje = new JButton("%");
        btnPorcentaje.setFont(font);
        btnPorcentaje.setForeground(Color.WHITE);
        btnPorcentaje.setUI(StyledButtonUI);

        btnUnoSobreX = new JButton("1/x");
        btnUnoSobreX.setFont(font);
        btnUnoSobreX.setForeground(Color.WHITE);
        btnUnoSobreX.setUI(StyledButtonUI);

        btnDivision = new JButton("/");
        btnDivision.setFont(font);
        btnDivision.setForeground(Color.WHITE);
        btnDivision.setUI(StyledButtonUI2);

        btnMultiplicar = new JButton("*");
        btnMultiplicar.setFont(font);
        btnMultiplicar.setForeground(Color.WHITE);
        btnMultiplicar.setUI(StyledButtonUI2);

        btnMenos = new JButton("-");
        btnMenos.setFont(font);
        btnMenos.setForeground(Color.WHITE);
        btnMenos.setUI(StyledButtonUI2);

        btnMas = new JButton("+");
        btnMas.setFont(font);
        btnMas.setForeground(Color.WHITE);
        btnMas.setUI(StyledButtonUI2);

        btnIgual = new JButton("=");
        btnIgual.setFont(font);
        btnIgual.setForeground(Color.WHITE);
        btnIgual.setUI(StyledButtonUI2);

        btnM = new JToggleButton("M");
        btnM.setFont(font);
        btnM.setUI(StyledButtonUI3);

        btnRetroceso = new JButton("Retroceso");
        btnRetroceso.setForeground(Color.WHITE);
        btnRetroceso.setFont(font);
        btnRetroceso.setUI(StyledButtonUI2);

        btnCE = new JButton("CE");
        btnCE.setForeground(Color.WHITE);
        btnCE.setFont(font);
        btnCE.setUI(StyledButtonUI2);

        btnC = new JButton("C");
        btnC.setForeground(Color.WHITE);
        btnC.setFont(font);
        btnC.setUI(StyledButtonUI2);

        btnMC = new JButton("MC");
        btnMC.setForeground(Color.WHITE);
        btnMC.setFont(font);
        btnMC.setUI(StyledButtonUI2);

        btnMR = new JButton("MR");
        btnMR.setForeground(Color.WHITE);
        btnMR.setFont(font);
        btnMR.setUI(StyledButtonUI2);

        btnMS = new JButton("MS");
        btnMS.setForeground(Color.WHITE);
        btnMS.setFont(font);
        btnMS.setUI(StyledButtonUI2);

        btnMPlus = new JButton("M+");
        btnMPlus.setForeground(Color.WHITE);
        btnMPlus.setFont(font);
        btnMPlus.setUI(StyledButtonUI2);

        //Botones numeros Fin

        //Pantalla Inicio
        tfPantalla = new JTextField("420,69");
        tfPantalla.setFont(new Font("arial", Font.PLAIN, 50));
        tfPantalla.setHorizontalAlignment(SwingConstants.RIGHT);
        tfPantalla.setEditable(false);
        tfPantalla.setBorder(new LineBorder(Color.BLUE,1,true));
        tfPantalla.setBackground(Color.CYAN);

        gbc.gridwidth = 6;
        add(tfPantalla, gbc);
        //Pantalla Fin


        //Agregar botones Inicio
        gbc.gridwidth = 1;

        gbc.gridy++;
        add(btnM, gbc);

        gbc.gridy++;
        add(btnMC, gbc);

        gbc.gridy++;
        add(btnMR, gbc);

        gbc.gridy++;
        add(btnMS, gbc);

        gbc.gridy++;
        add(btnMPlus, gbc);

        gbc.gridy=1;
        gbc.gridwidth = 2;

        gbc.gridx++;
        add(btnRetroceso, gbc);

        gbc.gridx++;
        gbc.gridx++;
        add(btnCE, gbc);

        gbc.gridx++;
        gbc.gridx++;
        add(btnC, gbc);


        gbc.gridwidth = 1;

        gbc.gridy = 2;
        gbc.gridx = 1;
        gbc.insets = new Insets(5,5,5,2);

        add(btnNumeros[7], gbc);

        gbc.gridy++;
        add(btnNumeros[4], gbc);

        gbc.gridy++;
        add(btnNumeros[1], gbc);

        gbc.gridy++;
        add(btnNumeros[0], gbc);

        gbc.gridy = 2;
        gbc.gridx = 2;
        gbc.insets = new Insets(5,2,5,2);

        add(btnNumeros[8], gbc);

        gbc.gridy++;
        add(btnNumeros[5], gbc);

        gbc.gridy++;
        add(btnNumeros[2], gbc);

        gbc.gridy++;
        add(btnMasSobreMenos, gbc);

        gbc.gridy = 2;
        gbc.gridx = 3;

        add(btnNumeros[9], gbc);

        gbc.gridy++;
        add(btnNumeros[6], gbc);

        gbc.gridy++;
        add(btnNumeros[3], gbc);

        gbc.gridy++;
        add(btnComa, gbc);

        gbc.gridy = 2;
        gbc.gridx = 4;

        add(btnDivision, gbc);

        gbc.gridy++;
        add(btnMultiplicar, gbc);

        gbc.gridy++;
        add(btnMenos, gbc);

        gbc.gridy++;
        add(btnMas, gbc);

        gbc.gridy = 2;
        gbc.gridx = 5;

        add(btnSqrt, gbc);

        gbc.gridy++;
        add(btnPorcentaje, gbc);

        gbc.gridy++;
        add(btnUnoSobreX, gbc);

        gbc.gridy++;
        add(btnIgual, gbc);
        //Agregar botones Fin






        setVisible(true);



    }

    public static void main(String[] args) {
        CalculadoraAWT app = new CalculadoraAWT();
    }
}
